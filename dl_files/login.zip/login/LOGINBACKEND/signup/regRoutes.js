const express = require('express');
const router = express.Router();

const RegCtrl = require('./regCtrl');

router.post('/register', RegCtrl.CreateUser);

module.exports = router;
