export interface Auth {
  username: string;
  email: string;
  password: string;
  token?: string;
  message?: string;
  user?: any;
}
