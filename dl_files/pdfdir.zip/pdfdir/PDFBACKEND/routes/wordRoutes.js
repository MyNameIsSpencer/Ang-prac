const express = require('express');
const router = express.Router();

const WordCtrl = require('../controllers/wordCtrl');

router.get('/word-to-pdf/:fileName', WordCtrl.DownloadFile);
router.post('/word-to-pdf', WordCtrl.WordToPdf);

module.exports = router;
